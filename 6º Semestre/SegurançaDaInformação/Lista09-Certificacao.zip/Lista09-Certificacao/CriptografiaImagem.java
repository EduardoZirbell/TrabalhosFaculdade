import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.security.PublicKey;
import java.security.cert.Certificate;

public class CriptografiaImagem {
    public static void main(String[] args) throws Exception {
        String caminhoRepo = "Lista09-Certificados";
        String senha = "FURB";
        String alias = "furb";
        String imgIn = "Lista09-Certificados/logo-sm.png";
        String imgOut = "img_cifrada.aes";
        String chaveOut = "key.aes";

        byte[] chave = "AAAAAAAAAAAAAAAA".getBytes();
        SecretKeySpec k = new SecretKeySpec(chave, "AES");
        Cipher aes = Cipher.getInstance("AES");
        aes.init(Cipher.ENCRYPT_MODE, k);

        FileInputStream in = new FileInputStream(imgIn);
        FileOutputStream out = new FileOutputStream(imgOut);
        byte[] buf = new byte[1024];
        int l;
        while ((l = in.read(buf)) != -1) {
            byte[] e = aes.update(buf, 0, l);
            if (e != null) out.write(e);
        }
        out.write(aes.doFinal());
        in.close();
        out.close();

        KeyStore ks = KeyStore.getInstance("JKS");
        ks.load(new FileInputStream(caminhoRepo), senha.toCharArray());
        Certificate c = ks.getCertificate(alias);
        PublicKey p = c.getPublicKey();

        Cipher rsa = Cipher.getInstance("RSA");
        rsa.init(Cipher.ENCRYPT_MODE, p);
        byte[] chaveEnc = rsa.doFinal(chave);

        FileOutputStream keyOut = new FileOutputStream(chaveOut);
        keyOut.write(chaveEnc);
        keyOut.close();

        System.out.println("Imagem cifrada: " + imgOut);
        System.out.println("Chave cifrada: " + chaveOut);
    }
}
