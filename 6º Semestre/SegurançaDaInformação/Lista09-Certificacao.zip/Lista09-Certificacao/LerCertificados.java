import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Collections;

public class LerCertificados {
    public static void main(String[] args) throws Exception {
        String repo = "Lista09-Certificados";
        String senha = "FURB";
        KeyStore ks = KeyStore.getInstance("JKS");
        ks.load(new FileInputStream(repo), senha.toCharArray());

        for (String nome : Collections.list(ks.aliases())) {
            Certificate c = ks.getCertificate(nome);
            if (c instanceof X509Certificate) {
                X509Certificate x = (X509Certificate) c;
                System.out.println("Alias: " + nome);
                System.out.println("Proprietario: " + x.getSubjectDN().getName());
                System.out.println("Emissor: " + x.getIssuerDN().getName());
                System.out.println("Autoassinado: " + (x.getSubjectDN().equals(x.getIssuerDN()) ? "Sim" : "Nao"));
                System.out.println("Valido de: " + x.getNotBefore());
                System.out.println("Ate: " + x.getNotAfter());
                System.out.println();
            }
        }
    }
}
