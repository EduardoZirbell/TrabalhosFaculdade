package Etapa1;

public class Estadia {

    private int horaEntrada;
    private int horaSaida;

    public Estadia() {
    }

    public Estadia(int horaEntrada, int horaSaida) {
        setHoraEntrada(horaEntrada);
        setHoraSaida(horaSaida);
    }

    public int getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(int horaEntrada) {
        if (horaEntrada < 0 || horaEntrada >= 24) {
            throw new IllegalArgumentException("Hora de entrada informada é inválida.");
        }
        this.horaEntrada = horaEntrada;
    }

    public int getHoraSaida() {
        return horaSaida;
    }

    public void setHoraSaida(int horaSaida) {
        if (horaSaida < 0 || horaSaida >= 24) {
            throw new IllegalArgumentException("Hora de saida informada é inválida.");
        }
        this.horaSaida = horaSaida;
    }

    /**
     * Calcula quanto tempo o veículo esteve no estacionamento.
     *
     * @return quantidade de horas que o veículo esteve estacionado.
     */
    public int calcularTempoEstadia() {
        int horasEstadia;
        /* IF: Verifica se o horário de saída é maior que o de entrada.
            True: horasEstadia = horário de saida - horário de entrada.
            Exemplo: 
                horasEstadia = 20 - 18;
                horasEstadia = 2;
            False: horasEstadia = (horário de saida - horário de entrada) + 24.
        Exemplo:
            horasEstadia = (2 - 20) + 24;
            horasEstadia = 2;
         */
        if (getHoraSaida() > getHoraEntrada()) {
            horasEstadia = getHoraSaida() - getHoraEntrada();
        } // 
        else {
            horasEstadia = (getHoraSaida() - getHoraEntrada()) + 24;
        }
        return horasEstadia;
    }

    /**
     * Calcula o valor da estadia baseado na quantidade de tempo de estadia do veículo.
     *
     * @return valor a ser pago pelo veículo.
     */
    public double calcularValorPagar() {
        // Recebe a quantidade de horas da estadia pela função.
        int horasEstadia = calcularTempoEstadia();
        // Recebe o valor devido ao valor mínimo para menos de 4h.
        double valorEstadia = 12.0;
        /* IF: Verifica se o horário de estadia é maior do que 4h.
            True: valorEstadia += (horasEstadia -4) * 3.
            Exemplo: 
                valorEstadia += (5 - 4) * 3;
                valorEstadia += 1 * 3;
                valorEstadia += 3;
         */
        if (horasEstadia > 4) {
            valorEstadia += (horasEstadia - 4) * 3.0;
        }
        return valorEstadia;
    }
}
