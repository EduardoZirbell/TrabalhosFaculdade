package Etapa1;

public class Main {

    public static void main(String[] args) {
        Estadia veiculo = new Estadia(17, 19);
        Estadia veiculo2 = new Estadia(20, 2);
        System.out.println(veiculo.calcularTempoEstadia());
        System.out.println(veiculo.calcularValorPagar());
        System.out.println(veiculo2.calcularTempoEstadia());
        System.out.println(veiculo2.calcularValorPagar());
    }
}
