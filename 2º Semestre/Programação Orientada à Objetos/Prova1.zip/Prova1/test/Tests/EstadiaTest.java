package Tests;

import org.junit.Test;
import static org.junit.Assert.*;
import Etapa1.Estadia;

public class EstadiaTest {

    /**
     * Caso Teste 1
     */
    @Test
    public void testcalcularValorPagar() {
        Estadia veiculo = new Estadia(20, 2);
        assertEquals(18, veiculo.calcularValorPagar(), 0);
    }
}
