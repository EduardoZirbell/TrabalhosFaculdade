package main;

public class NoArvoreBinaria<T> {

        private T info;
        private NoArvoreBinaria<T> esquerda;
        private NoArvoreBinaria<T> direita;

        public NoArvoreBinaria(T info) {
            this.info = info;
        }
        public NoArvoreBinaria(T info,NoArvoreBinaria<T> esq,NoArvoreBinaria<T> dir) {
            this.esquerda = esq;
            this.direita = dir;
            this.info = info;
        }
        public T getInfo() {
            return info;
        }

        public void setInfo(T info) {
            this.info = info;
        }

        public NoArvoreBinaria<T> getEsquerda(){
         return esquerda;
        }
        public NoArvoreBinaria<T> getDireita(){
         return direita;
        }

        public void setEsquerda(NoArvoreBinaria<T> esq){
        this.esquerda = esq;
        }
        public void setDireita(NoArvoreBinaria<T> dir){
        this.direita = dir;
    }
        @Override
        public int hashCode() {
            int hash = 5;
            return hash;
        }


    }


