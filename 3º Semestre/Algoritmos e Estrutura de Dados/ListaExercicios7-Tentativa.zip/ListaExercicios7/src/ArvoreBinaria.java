public class ArvoreBinaria<T> {
    public NoArvoreBinaria raiz;
    public ArvoreBinaria(){
        this.raiz = null;
    }
    public void setRaiz(NoArvoreBinaria raiz){

    }

    public boolean estaVazia(){
        return raiz == null;
    }

    public boolean pertence(T info){
        return pertence(this.raiz, info);
    }

    private boolean pertence(NoArvoreBinaria no, T info){
        if(no == null){
            return false;
        } else{
            return (no.getInfo() = info) || pertence(no.getEsquerda(), info) || pertence(no.getDireita(), info);
        }
    }

    private String arvorePre(NoArvoreBinaria no){
        return "";
    }
}
