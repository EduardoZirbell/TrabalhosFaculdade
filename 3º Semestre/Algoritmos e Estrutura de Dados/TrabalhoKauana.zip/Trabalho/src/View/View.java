package View;
import Funcoes.PilhaLista;
import HTML.Arquivo;
import HTML.ContadorTagHTML;
import HTML.ValidadorHTML;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class View extends javax.swing.JFrame {
    private StringBuilder conteudoHTML;

    public void inicial(){
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new View().setVisible(true);
            }
        });
    }

    private void exibirOcorrencias() {
        ContadorTagHTML contadorTag = new ContadorTagHTML();
        contadorTag.contarTags(conteudoHTML);
        PilhaLista<String> tags = contadorTag.getTagsMultiplas();
        PilhaLista<Integer> contador = contadorTag.getContadorMultiplos();
        DefaultTableModel model = (DefaultTableModel) tableOcorrencias.getModel();
        model.setNumRows(0);
        while (!tags.estaVazia()) {
            model.addRow(new Object[]{tags.pop(), contador.pop()});
        }

    }

    private boolean validarArquivoHTML(File arquivo) {
        if (!arquivo.getName().endsWith(".html") && !arquivo.getName().endsWith(".htm")) {
            return false;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            String linha;
            boolean contemTagHTML = false;
            while ((linha = br.readLine()) != null) {
                if (linha.trim().matches(".*<html.*>|.*</html>.*")) {
                    contemTagHTML = true;
                    break;
                }
            }
            if (!contemTagHTML) {
                JOptionPane.showMessageDialog(null, "O arquivo não contém tags HTML.");
                return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private void exibirValidacaoHTML(){
        ValidadorHTML validador = new ValidadorHTML();
        validador.validarHTML(conteudoHTML);

        if (validador.isValidHtml()) {
            jTextHtmlValidacao.setText("O arquivo está bem formatado.");

        } else {
            jTextHtmlValidacao.setText("O arquivo não está bem formatado.");
            jTextHtmlValidacao.append("\nTags não fechadas: " + validador.getTagsAbertas());
        }
    }

    public View() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        JinputFile = new javax.swing.JTextField();
        JButtonAnalisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableOcorrencias = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextHtmlValidacao = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Arquivo");

        JinputFile.setEditable(false);
        JinputFile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JinputFileMouseClicked(evt);
            }
        });
        JinputFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JinputFileActionPerformed(evt);
            }
        });

        JButtonAnalisar.setText("Analisar");
        JButtonAnalisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButtonAnalisarActionPerformed(evt);
            }
        });

        tableOcorrencias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Tag", "Número de Ocorrências"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tableOcorrencias);

        jTextHtmlValidacao.setColumns(20);
        jTextHtmlValidacao.setRows(5);
        jScrollPane2.setViewportView(jTextHtmlValidacao);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(JinputFile, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(JButtonAnalisar))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(JinputFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JButtonAnalisar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 169, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JinputFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JinputFileActionPerformed

    }//GEN-LAST:event_JinputFileActionPerformed

    private void JinputFileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JinputFileMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_JinputFileMouseClicked


    private void JButtonAnalisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButtonAnalisarActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Escolha um arquivo "); // Título da janela de diálogo
        fileChooser.setAcceptAllFileFilterUsed(false); // Desativa a opção de selecionar todos os tipos de arquivos
        fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("Arquivos de Texto", "html")); // Filtra para mostrar apenas arquivos de texto
        int result = fileChooser.showOpenDialog(null); // null significa que a janela não tem um componente pai
        if (result == JFileChooser.APPROVE_OPTION) {// O usuário selecionou um arquivo
            File selectedFile = fileChooser.getSelectedFile(); //Captura a informação do arquivo selecionado
            JinputFile.setText(selectedFile.getAbsolutePath());//seta o path do arquivo no capo de input
            if (validarArquivoHTML(selectedFile.getAbsoluteFile())) {
                Arquivo arquivo = new Arquivo(selectedFile.getAbsolutePath());
                 conteudoHTML = arquivo.lerArquivo(); //Chama o metodo de converter os dados do HTML para StringBuilder
                exibirOcorrencias(); //Chama o metodo para inserir os dados no Jtable Ocorrencias
                exibirValidacaoHTML(); //Chama o metodo para inserir os dados no Jtext HTMLvalidacao
            }
        }

    }//GEN-LAST:event_JButtonAnalisarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButtonAnalisar;
    private javax.swing.JTextField JinputFile;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextHtmlValidacao;
    private javax.swing.JTable tableOcorrencias;
    // End of variables declaration//GEN-END:variables
}
