package Funcoes;

public class NoLista<Publicacao> {

    private Publicacao info;
    private NoLista<Publicacao> proximo;

    public Publicacao getInfo() {
        return info;
    }

    public void setInfo(Publicacao info) {
        this.info = info;
    }

    public NoLista<Publicacao> getProximo() {
        return proximo;
    }

    public void setProximo(NoLista<Publicacao> proximo) {
        this.proximo = proximo;
    }


}
