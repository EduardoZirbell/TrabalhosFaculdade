package Funcoes;

public interface Pilha<T> {
    public void push(T elemento);

    public T pop();

    public T peek();

    public Boolean estaVazia();

    public void liberar();
}
