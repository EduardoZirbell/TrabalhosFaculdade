package Funcoes;

public class PilhaLista<T> implements Pilha<T> {

    private ListaEncadeada lista;

    public PilhaLista(int limite) {
        lista = new ListaEncadeada();
    }

    @Override
    public T pop() {
        T valor;
        if (estaVazia()) {
            throw new RuntimeException("Functions.Pilha vazia. Não há elementos para visualizar.");
        } else {
            valor = peek();
            lista.retirar(valor);
        }
        return valor;
    }

    @Override
    public T peek() {
        if (estaVazia()) {
            throw new RuntimeException("Functions.Pilha vazia. Não há elementos para visualizar.");
        }
        return (T) lista.getPrimeiro().getInfo();
    }

    @Override
    public Boolean estaVazia() {
        return lista.estaVazia();
    }

    @Override
    public void liberar() {
        lista = new ListaEncadeada();
    }

    @Override
    public void push(T info) {
        lista.inserir(info);
    }

    @Override
    public String toString() {
        return lista.toString();
    }
}
