package HTML;

import Funcoes.PilhaLista;

public class ContadorTagHTML {

    private PilhaLista<String> tags;
    private PilhaLista<Integer> cont;
    private PilhaLista<String> tagsAbertas;

    public PilhaLista<String> getTags() {
        return tags;
    }

    public ContadorTagHTML() {
        this.tags = new PilhaLista<>(100);
        this.cont = new PilhaLista<>(100);
        this.tagsAbertas = new PilhaLista<>(100);
    }

    public void contarTags(StringBuilder htmlContent) {
        ValidadorHTML validador = new ValidadorHTML();

        int i = 0;
        while (i < htmlContent.length()) {
            if (htmlContent.charAt(i) == '<') {
                int comecoTag = i;
                int fimTag = htmlContent.indexOf(">", comecoTag);
                if (fimTag == -1) {
                    break;
                }

                String tag = htmlContent.substring(comecoTag, fimTag + 1);

                if (validador.isTagSingleton(tag)) {
                    String nomeTag = validador.extrairNomeTag(tag);
                    contadorTag(nomeTag);
                }

                else if (tag.startsWith("</")) {
                    String nomeTag = validador.extrairNomeTag(tag);
                    if (!tagsAbertas.estaVazia() && tagsAbertas.peek().equals(nomeTag)) {
                        tagsAbertas.pop();
                        contadorTag(nomeTag);
                    }
                } else if (!tag.endsWith("/>")) {

                    String nomeTag = validador.extrairNomeTag(tag);
                    tagsAbertas.push(nomeTag);
                }
                i = fimTag;
            }
            i++;
        }
    }

    private void contadorTag(String tag) {
        Integer count = getContadorTag(tag);
        if (count == null) {
            tags.push(tag);
            cont.push(1);
        } else {
            setContadorTag(tag, count + 1);
        }
    }

    private Integer getContadorTag(String tag) {
        PilhaLista<String> tagTemporaria = new PilhaLista<>(100);
        PilhaLista<Integer> contadorTemporario = new PilhaLista<>(100);
        Integer count = null;

        while (!tags.estaVazia()) {
            String tagAtual = tags.pop();
            Integer contadorAtual = cont.pop();
            if (tagAtual.equals(tag)) {
                count = contadorAtual;
            }
            tagTemporaria.push(tagAtual);
            contadorTemporario.push(contadorAtual);
        }

        while (!tagTemporaria.estaVazia()) {
            tags.push(tagTemporaria.pop());
            cont.push(contadorTemporario.pop());
        }

        return count;
    }

    private void setContadorTag(String tag, int newCount) {
        PilhaLista<String> tagTemporaria = new PilhaLista<>(100);
        PilhaLista<Integer> contadorTemporario = new PilhaLista<>(100);

        while (!tags.estaVazia()) {
            String tagAtual = tags.pop();
            Integer contadorAtual = cont.pop();
            if (tagAtual.equals(tag)) {
                contadorAtual = newCount;
            }
            tagTemporaria.push(tagAtual);
            contadorTemporario.push(contadorAtual);
        }

        while (!tagTemporaria.estaVazia()) {
            tags.push(tagTemporaria.pop());
            cont.push(contadorTemporario.pop());
        }
    }

    public PilhaLista<String> getTagsMultiplas() {
        PilhaLista<String> copia = new PilhaLista<>(100);
        PilhaLista<String> tagTemporaria = new PilhaLista<>(100);

        while (!tags.estaVazia()) {
            String tag = tags.pop();
            tagTemporaria.push(tag);
            copia.push(tag);
        }

        while (!tagTemporaria.estaVazia()) {
            tags.push(tagTemporaria.pop());
        }

        return copia;
    }

    public PilhaLista<Integer> getContadorMultiplos() {
        PilhaLista<Integer> copia = new PilhaLista<>(100);
        PilhaLista<Integer> contadorTemporario = new PilhaLista<>(100);

        while (!cont.estaVazia()) {
            Integer count = cont.pop();
            contadorTemporario.push(count);
            copia.push(count);
        }

        while (!contadorTemporario.estaVazia()) {
            cont.push(contadorTemporario.pop());
        }

        return copia;
    }
}
