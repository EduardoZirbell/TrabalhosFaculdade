package HTML;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Arquivo {

    private String caminhoArquivo;
    private StringBuilder conteudoHTML = new StringBuilder();

    public Arquivo() {
    }

    public Arquivo(String caminhoArquivo) {
        this.caminhoArquivo = caminhoArquivo;
    }

    public String getCaminhoArquivo() {
        return caminhoArquivo;
    }

    public void setCaminhoArquivo(String caminhoArquivo) {
        this.caminhoArquivo = caminhoArquivo;
    }

    public StringBuilder getConteudoHTML() {
        return conteudoHTML;
    }

    public StringBuilder lerArquivo() {
        if (caminhoArquivo == null || caminhoArquivo.isEmpty()) {
            System.err.println("Caminho do arquivo não definido ou vazio.");
            return conteudoHTML;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(caminhoArquivo))) {
            String line;
            while ((line = br.readLine()) != null) {
                conteudoHTML.append(line).append("\n");
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo: " + e.getMessage());
        }
        return conteudoHTML;
    }
}