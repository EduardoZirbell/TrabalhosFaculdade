package HTML;

import Funcoes.PilhaLista;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidadorHTML {
    private PilhaLista<String> tagsAbertas;
    private boolean isValid;
    private int contadorTagSingleton;

    private static final Pattern SINGLETON_TAG_PATTERN = Pattern.compile(
            "<(|!DOCTYPE|html|body|area|base|br|col|command|embed|hr|img|input|keygen|link|meta|param|source|track|wbr)(\\s[^>]*)?>",
            Pattern.CASE_INSENSITIVE
    );

    public ValidadorHTML() {
        this.tagsAbertas = new PilhaLista<>(10);
        this.isValid = true;
        this.contadorTagSingleton = 0;
    }

    public void validarHTML(StringBuilder conteudoHTML) {
        int i = 0;
        while (i < conteudoHTML.length()) {
            if (conteudoHTML.charAt(i) == '<') {
                int comecoTag = i;
                int fimTag = conteudoHTML.indexOf(">", comecoTag);
                if (fimTag == -1) {
                    break;
                }

                String tag = conteudoHTML.substring(comecoTag, fimTag + 1);

                if (isTagSingleton(tag)) {
                    contadorTagSingleton++;
                }

                else if (tag.startsWith("</")) {
                    String nomeTag = extrairNomeTag(tag);
                    if (!tagsAbertas.estaVazia() && tagsAbertas.peek().equals(nomeTag)) {
                        tagsAbertas.pop();
                    } else {
                        isValid = false;
                    }
                } else if (!tag.endsWith("/>")) {

                    String nomeTag = extrairNomeTag(tag);
                    tagsAbertas.push(nomeTag);
                }
                i = fimTag;
            }
            i++;
        }

        if (!tagsAbertas.estaVazia()) {
            isValid = false;
        }
    }

    public String extrairNomeTag(String tag) {
        return tag.replaceAll("[</>]", "").split("\\s")[0];
    }

    public boolean isTagSingleton(String tag) {
        if (tag == null || tag.trim().isEmpty()) {
            return false;
        }
        tag = tag.trim();

        Matcher matcher = SINGLETON_TAG_PATTERN.matcher(tag);

        return matcher.matches();
    }

    public boolean isValidHtml() {
        return isValid;
    }

    public PilhaLista<String> getTagsAbertas() {
        return tagsAbertas;
    }

    public int getContadorTagSingleton() {
        return contadorTagSingleton;
    }

}
