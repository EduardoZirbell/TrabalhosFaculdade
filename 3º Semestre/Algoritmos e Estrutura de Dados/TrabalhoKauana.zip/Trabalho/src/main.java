import View.View;

import java.io.IOException;

public class main {
    public static void main(String[] args) throws IOException {
        View panel = new View();
        panel.inicial();
    }
}