import org.junit.Assert;
import org.junit.Test;

import java.time.LocalDate;


public class MapaDispersaoTest {
    @Test
    public void validaInserirAluno() {
        Aluno aluno = new Aluno(12000, "Walter", LocalDate.of(2000, 1, 1));
        MapaDispersao mapaDispersao = new MapaDispersao<>(53);
        mapaDispersao.inserir(12000, aluno);
        Assert.assertEquals(aluno, mapaDispersao.buscar(12000));
    }

    @Test
    public void validaInserirDiversosAlunos() {
        Aluno aluno1 = new Aluno(12000, "Jean", LocalDate.of(2000, 1, 1));
        Aluno aluno2 = new Aluno(14000, "Pedro", LocalDate.of(1999, 1, 20));
        Aluno aluno3 = new Aluno(12500, "Marta", LocalDate.of(2001, 2, 18));
        Aluno aluno4 = new Aluno(13000, "Lucas", LocalDate.of(1998, 11, 25));

        MapaDispersao mapaDispersao = new MapaDispersao<>(53);
        mapaDispersao.inserir(12000, aluno1);
        mapaDispersao.inserir(14000, aluno2);
        mapaDispersao.inserir(12500, aluno3);
        mapaDispersao.inserir(13000, aluno4);
        Assert.assertEquals(aluno1, mapaDispersao.buscar(12000));
        Assert.assertEquals(aluno2, mapaDispersao.buscar(14000));
        Assert.assertEquals(aluno3, mapaDispersao.buscar(12500));
        Assert.assertEquals(aluno4, mapaDispersao.buscar(13000));
    }

    @Test
    public void validaInserirBuscarAlunoCColisao() {
        Aluno aluno1 = new Aluno(12500, "Jean", LocalDate.of(2000, 1, 1));
        Aluno aluno2 = new Aluno(14000, "Pedro", LocalDate.of(1999, 1, 20));
        Aluno aluno3 = new Aluno(14226, "Marta", LocalDate.of(2001, 2, 18));
        Aluno aluno4 = new Aluno(17180, "Lucas", LocalDate.of(1998, 11, 25));
        MapaDispersao mapaDispersao = new MapaDispersao<>(53);
        mapaDispersao.inserir(12500, aluno1);
        mapaDispersao.inserir(14000, aluno2);
        mapaDispersao.inserir(14226, aluno3);
        mapaDispersao.inserir(17180, aluno4);
        Assert.assertEquals(aluno1, mapaDispersao.buscar(12500));
        Assert.assertEquals(aluno2, mapaDispersao.buscar(14000));
        Assert.assertEquals(aluno3, mapaDispersao.buscar(14226));
        Assert.assertEquals(aluno4, mapaDispersao.buscar(17180));
    }
}
